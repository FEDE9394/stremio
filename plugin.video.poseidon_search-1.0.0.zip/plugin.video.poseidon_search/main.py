# -*- coding: utf-8 -*-
"""
Buscador PoseidonHD - Addon para Kodi
Compatible con Kodi 19 Matrix, 20 Nexus y 21 Omega
Sitio objetivo: https://www.poseidonhd2.co/
Versión 1.1.0 - Con resolvers integrados autónomos
"""

import sys
import re
import json
import time
import base64
import hashlib
from urllib.parse import parse_qsl, quote_plus, urlparse, parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import requests
from bs4 import BeautifulSoup

# Intentar importar resolveurl como último recurso
try:
    import resolveurl
    RESOLVEURL_AVAILABLE = True
except ImportError:
    RESOLVEURL_AVAILABLE = False

# Intentar importar cryptography para AES-GCM (necesario para Filemoon)
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAVE_CRYPTOGRAPHY = True
except ImportError:
    _HAVE_CRYPTOGRAPHY = False
    AESGCM = None

# Intentar PyCryptodome como fallback para AES-GCM
try:
    from Cryptodome.Cipher import AES as PyCryptoAES
    _HAVE_PYCRYPTO = True
except ImportError:
    try:
        from Crypto.Cipher import AES as PyCryptoAES
        _HAVE_PYCRYPTO = True
    except ImportError:
        _HAVE_PYCRYPTO = False
        PyCryptoAES = None

# Configuración básica
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
BASE_URL = 'https://www.poseidonhd2.co'

# Headers de navegador de escritorio real
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}


# ===========================================================================
# UTILIDADES GENERALES
# ===========================================================================

def log(message, level=xbmc.LOGINFO):
    """Escribe logs en el sistema de Kodi."""
    xbmc.log(f"[{ADDON_NAME}] {message}", level)


def show_notification(title, message, icon=None, time_ms=5000):
    """Muestra una notificación en la interfaz de Kodi."""
    dialog = xbmcgui.Dialog()
    dialog.notification(title, message, icon or xbmcgui.NOTIFICATION_INFO, time_ms)


def get_html(url, referer=None, extra_headers=None, timeout=20):
    """Realiza una petición HTTP GET y retorna el texto HTML."""
    headers = HEADERS.copy()
    if referer:
        headers['Referer'] = referer
    if extra_headers:
        headers.update(extra_headers)
    try:
        session = requests.Session()
        session.headers.update(headers)
        response = session.get(url, timeout=timeout, allow_redirects=True)
        response.raise_for_status()
        return response.text
    except Exception as e:
        log(f"Error realizando petición HTTP a {url}: {str(e)}", xbmc.LOGERROR)
        return None


def get_json(url, referer=None, extra_headers=None, timeout=20):
    """Realiza una petición HTTP GET y retorna el JSON parseado."""
    headers = HEADERS.copy()
    if referer:
        headers['Referer'] = referer
    if extra_headers:
        headers.update(extra_headers)
    try:
        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        log(f"Error obteniendo JSON de {url}: {str(e)}", xbmc.LOGERROR)
        return None


def extract_next_data(html):
    """Extrae y parsea el objeto __NEXT_DATA__ de una página Next.js."""
    if not html:
        return None
    try:
        soup = BeautifulSoup(html, 'html.parser')
        script_tag = soup.find('script', id='__NEXT_DATA__')
        if script_tag and script_tag.string:
            return json.loads(script_tag.string)
    except Exception as e:
        log(f"Error al extraer __NEXT_DATA__: {str(e)}", xbmc.LOGERROR)
    return None


# ===========================================================================
# UNPACKER DE DEAN EDWARDS (P,A,C,K,E,D) - Implementación pura Python
# ===========================================================================

def _packer_detect(source):
    """Detecta si el código JS está empaquetado con el packer de Dean Edwards."""
    return source.strip().startswith("eval(function(p,a,c,k,e,")


def _packer_unpack(source):
    """
    Desempaqueta código JavaScript comprimido con el packer de Dean Edwards.
    Implementación pura en Python sin js2py.
    """
    try:
        # Extraer los argumentos del packer: p, a, c, k, e, d
        match = re.search(
            r"eval\(function\(p,a,c,k,e,(?:r|d)\)\{.*?return p\}",
            source, re.DOTALL
        )
        if not match:
            return source

        # Extraer parámetros: código, radix, count, keywords
        inner = re.search(
            r"'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'",
            source
        )
        if not inner:
            return source

        payload = inner.group(1).replace("\\'", "'").replace("\\\\", "\\")
        radix = int(inner.group(2))
        count = int(inner.group(3))
        keywords_raw = inner.group(4).replace("\\'", "'")

        # Dividir keywords
        if '|' in keywords_raw:
            keywords = keywords_raw.split('|')
        else:
            keywords = re.split(r'\|', keywords_raw)

        def base_decode(num_str, base):
            """Convierte un número en base 'base' a entero."""
            chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
            result = 0
            num_str = num_str.strip()
            for char in num_str:
                result = result * base + chars.index(char)
            return result

        def replace_match(m):
            """Reemplaza cada token con su keyword correspondiente."""
            word = m.group(0)
            try:
                index = base_decode(word, radix)
                if index < len(keywords) and keywords[index]:
                    return keywords[index]
                return word
            except (ValueError, IndexError):
                return word

        # Reemplazar todos los tokens en el payload
        unpacked = re.sub(r'\b\w+\b', replace_match, payload)
        return unpacked

    except Exception as e:
        log(f"Error en _packer_unpack: {str(e)}", xbmc.LOGWARNING)
        return source


# ===========================================================================
# RESOLVERS DE SERVIDORES DE VIDEO
# ===========================================================================

def resolve_streamwish(embed_url):
    """
    Resuelve URLs de Streamwish, Wishonly, JwplayerHLS y sitios similares.
    Usa una sesión con cookies para obtener el contenido real del player.
    Estrategia 1: Sesión con cookies (simula un browser real)
    Estrategia 2: Desempaquetar P,A,C,K,E,D si está disponible
    """
    log(f"[Resolver] Streamwish: {embed_url}")

    # Extraer referer del pipe si existe: url|Referer=...
    referer = embed_url
    if '|Referer=' in embed_url or '|referer=' in embed_url:
        parts = embed_url.split('|', 1)
        embed_url = parts[0]
        qs = dict(p.split('=', 1) for p in parts[1].split('&') if '=' in p)
        referer = qs.get('Referer') or qs.get('referer') or embed_url

    parsed = urlparse(embed_url)
    base_domain = f"{parsed.scheme}://{parsed.netloc}"

    # Usar sesión con cookies para simular un navegador real
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': referer,
    })

    # Paso 1: Visitar la página principal del dominio para obtener cookies
    try:
        session.get(base_domain, timeout=10)
    except Exception:
        pass

    # Paso 2: Obtener la página del embed
    try:
        resp = session.get(embed_url, timeout=20)
        html = resp.text
    except Exception as e:
        log(f"[Resolver] Streamwish: Error HTTP: {str(e)}", xbmc.LOGWARNING)
        return None

    if not html or len(html) < 100:
        log("[Resolver] Streamwish: HTML vacío o demasiado corto.", xbmc.LOGWARNING)
        return None

    # Si la página es la de 'loading...' (SPA protegida), intentar el main.js
    if 'Page is loading' in html or (len(html) < 1000 and 'main.js' in html):
        log("[Resolver] Streamwish: Página de carga detectada, intentando main.js...", xbmc.LOGWARNING)
        # Obtener el main.js para encontrar el endpoint de API
        try:
            # Encontrar la versión del main.js
            js_ver = re.search(r'main\.js\?v=([\d.]+)', html)
            js_url = f"{base_domain}/main.js" + (f"?v={js_ver.group(1)}" if js_ver else "")
            js_resp = session.get(js_url, timeout=15)
            js_content = js_resp.text

            # En el JS obfuscado, buscar el endpoint de la API de forma heurística
            # Los endpoints suelen aparecer como strings entre comillas
            api_paths = re.findall(r'["\'](\/(?:api|get|source|player)\/[^"\',]{2,50})["\']', js_content)
            log(f"[Resolver] Streamwish: API paths en main.js: {api_paths[:5]}")
        except Exception:
            pass
        return None

    # Buscar sección packed P,A,C,K,E,D en el HTML
    packed_html = html
    pack_match = re.search(r'(eval\(function\(p,a,c,k,e,(?:r|d)\).*?)</script>', html, re.DOTALL)
    if pack_match:
        packed_code = pack_match.group(1)
        unpacked = _packer_unpack(packed_code)
        packed_html = unpacked + html  # Combinar ambos
    else:
        packed_html = html

    # Patrones para extraer la fuente m3u8/mp4 (ordenados por prioridad)
    patterns = [
        r'["\']hls[2]?["\']\s*:\s*["\']([^"\']+(m3u8|mp4)[^"\']*)["\'`]',
        r'(?:file|"hls\d*")\s*:\s*["\']([^"\']+(m3u8|mp4)[^"\']*)["\'`]',
        r'"file"\s*:\s*"(https?://[^"]+)"',
        r"source\s*:\s*'(https?://[^']+\.m3u8[^']*)'" ,
        r'sources\s*:\s*\[.*?"file"\s*:\s*"([^"]+)"',
        r'"src"\s*:\s*"(https?://[^"]+\.m3u8[^"]*)',
        r'(?:file|src)\s*=\s*["\']?(https?://[^"\'>\s]+\.(?:m3u8|mp4)[^"\'>\s]*)',
        r'(https?://[^\s"\',<>]+\.m3u8(?:\?[^\s"\',<>]*)?)',
    ]

    for pattern in patterns:
        m = re.search(pattern, packed_html, re.DOTALL | re.IGNORECASE)
        if m:
            url = m.group(1)
            if url and url.startswith('http') and ('m3u8' in url or 'mp4' in url):
                log(f"[Resolver] Streamwish => {url}")
                return url

    log("[Resolver] Streamwish: No se encontró fuente de video en el HTML.", xbmc.LOGWARNING)
    return None




def resolve_filemoon(embed_url):
    """
    Resuelve URLs de Filemoon/Filemooon usando su API y descifrado AES-256-GCM.
    Soporta cryptography y PyCryptodome.
    """
    log(f"[Resolver] Filemoon: {embed_url}")

    if not (_HAVE_CRYPTOGRAPHY or _HAVE_PYCRYPTO):
        log("[Resolver] Filemoon: No hay librería AES disponible (cryptography o pycryptodome).", xbmc.LOGWARNING)
        return None

    # Extraer el ID del video desde la URL
    match = re.search(r'/(?:e|d)/([a-z0-9]+)', embed_url)
    if not match:
        log("[Resolver] Filemoon: No se encontró ID de video en la URL.", xbmc.LOGWARNING)
        return None

    video_id = match.group(1)
    # Determinar el dominio base para la API
    parsed = urlparse(embed_url)
    base_domain = f"{parsed.scheme}://{parsed.netloc}"

    playback_url = f"{base_domain}/api/videos/{video_id}/embed/playback"
    headers_extra = {'Referer': embed_url}
    data = get_json(playback_url, extra_headers=headers_extra)

    if not data or data.get('error'):
        # Intentar con filemooon.link como fallback
        playback_url = f"https://filemooon.link/api/videos/{video_id}/embed/playback"
        data = get_json(playback_url, extra_headers=headers_extra)

    if not data or data.get('error'):
        log(f"[Resolver] Filemoon: Error al obtener datos de playback.", xbmc.LOGWARNING)
        return None

    playback_data = data.get('playback', {})
    try:
        algorithm = playback_data.get('algorithm')
        iv_b64 = playback_data.get('iv')
        payload_b64 = playback_data.get('payload')
        key_parts = playback_data.get('key_parts', [])

        if algorithm != 'AES-256-GCM' or len(key_parts) != 2:
            log(f"[Resolver] Filemoon: Algoritmo no soportado o key_parts inválidos.", xbmc.LOGWARNING)
            return None

        def b64u_decode(s):
            s = s.replace('-', '+').replace('_', '/')
            padding = len(s) % 4
            if padding:
                s += '=' * (4 - padding)
            return base64.b64decode(s)

        iv = b64u_decode(iv_b64)
        payload = b64u_decode(payload_b64)
        kp1, kp2 = key_parts

        try:
            k1 = b64u_decode(kp1)
        except Exception:
            k1 = kp1.encode()
        try:
            k2 = b64u_decode(kp2)
        except Exception:
            k2 = kp2.encode()

        raw_key = k1 + k2
        key = raw_key if len(raw_key) == 32 else hashlib.sha256(raw_key).digest()

        pt = None
        if _HAVE_CRYPTOGRAPHY and AESGCM is not None:
            aesgcm = AESGCM(key)
            pt = aesgcm.decrypt(iv, payload, None)
        elif _HAVE_PYCRYPTO and PyCryptoAES is not None:
            if len(payload) < 16:
                raise ValueError('Payload demasiado corto para tag GCM')
            tag = payload[-16:]
            ciphertext = payload[:-16]
            cipher = PyCryptoAES.new(key, PyCryptoAES.MODE_GCM, nonce=iv)
            pt = cipher.decrypt_and_verify(ciphertext, tag)
        else:
            return None

        decrypted = json.loads(pt.decode('utf-8', errors='replace'))
        m3u8_url = decrypted.get('sources', [{}])[0].get('url')
        if m3u8_url:
            log(f"[Resolver] Filemoon => {m3u8_url}")
            # Agregar headers necesarios para reproducir
            host = base_domain
            header_str = f"|Referer={host}/&Origin={host}"
            return m3u8_url + header_str

    except Exception as e:
        log(f"[Resolver] Filemoon: Error de descifrado: {str(e)}", xbmc.LOGERROR)

    return None


def resolve_streamtape(embed_url):
    """
    Resuelve URLs de Streamtape extrayendo el enlace directo desde la página.
    """
    log(f"[Resolver] Streamtape: {embed_url}")

    html = get_html(embed_url, referer=embed_url)
    if not html:
        return None

    if 'Video not found' in html or 'Video is converting' in html:
        log("[Resolver] Streamtape: Video no encontrado o convirtiendo.", xbmc.LOGWARNING)
        return None

    # Streamtape construye la URL por medio de JS con innerHTML
    # Patrón: innerHTML = 'https:....' + (innerHTMl | '....')
    matches = re.findall(r"innerHTML\s*=\s*([^;]+)", html)
    if len(matches) >= 2:
        try:
            # Limpiar y concatenar los fragmentos
            part1 = re.search(r"'([^']+)'", matches[-2])
            part2 = re.search(r"'([^']+)'", matches[-1])
            if part1 and part2:
                raw_url = "https:" + part1.group(1) + part2.group(1)
                # Streamtape a veces necesita una redirección a la URL final
                try:
                    resp = requests.head(raw_url, headers=HEADERS, timeout=10, allow_redirects=True)
                    final_url = resp.url
                except Exception:
                    final_url = raw_url
                log(f"[Resolver] Streamtape => {final_url}")
                return f"{final_url}|User-Agent={HEADERS['User-Agent']}"
        except Exception as e:
            log(f"[Resolver] Streamtape: Error procesando JS: {str(e)}", xbmc.LOGWARNING)

    return None


def resolve_doodstream(embed_url):
    """
    Resuelve URLs de DoodStream generando el token de reproducción.
    """
    log(f"[Resolver] Doodstream: {embed_url}")

    headers = HEADERS.copy()
    headers['Referer'] = embed_url

    try:
        resp = requests.get(embed_url, headers=headers, timeout=20, allow_redirects=True)
        html = resp.text
        final_url = resp.url
    except Exception as e:
        log(f"[Resolver] Doodstream: Error HTTP: {str(e)}", xbmc.LOGWARNING)
        return None

    if 'Video not found' in html:
        return None

    # Extraer el path /pass_md5/... desde el JS
    pass_match = re.search(r"\$\.get\('(/pass_md5[^']+)'", html)
    if not pass_match:
        # Intentar buscar en formato alternativo
        pass_match = re.search(r"(/pass_md5/[^'\"]+)", html)

    if not pass_match:
        log("[Resolver] Doodstream: No se encontró pass_md5.", xbmc.LOGWARNING)
        return None

    parsed = urlparse(final_url)
    host = f"{parsed.scheme}://{parsed.netloc}"
    pass_url = host + pass_match.group(1)

    headers['Referer'] = final_url
    try:
        pass_resp = requests.get(pass_url, headers=headers, timeout=20)
        base_video_url = pass_resp.text.strip()
    except Exception as e:
        log(f"[Resolver] Doodstream: Error obteniendo pass_md5: {str(e)}", xbmc.LOGWARNING)
        return None

    # El token de tiempo se agrega al final
    token = str(int(time.time() * 1000))
    final_video_url = base_video_url + token
    log(f"[Resolver] Doodstream => {final_video_url}")
    return f"{final_video_url}|Referer={final_url}"


def resolve_voe(embed_url):
    """
    Resuelve URLs de VOE extrayendo el enlace .m3u8 o .mp4 de la página.
    """
    log(f"[Resolver] VOE: {embed_url}")

    html = get_html(embed_url, referer=embed_url)
    if not html:
        return None

    # Buscar 'hls' o 'mp4' en el JS de VOE
    patterns = [
        r"'hls'\s*:\s*'([^']+)'",
        r'"hls"\s*:\s*"([^"]+)"',
        r"'mp4'\s*:\s*'([^']+)'",
        r'"mp4"\s*:\s*"([^"]+)"',
        r"sources\s*=\s*\[.*?\"file\"\s*:\s*\"([^\"]+)\"",
    ]
    for pattern in patterns:
        m = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
        if m:
            url = m.group(1)
            log(f"[Resolver] VOE => {url}")
            return url

    log("[Resolver] VOE: No se encontró fuente de video.", xbmc.LOGWARNING)
    return None


def resolve_mixdrop(embed_url):
    """
    Resuelve URLs de Mixdrop buscando la URL del video en el HTML/JS de la página.
    """
    log(f"[Resolver] Mixdrop: {embed_url}")

    html = get_html(embed_url, referer=embed_url)
    if not html:
        return None

    # Buscar la URL del video en el JS
    # Puede estar empaquetada
    if _packer_detect(html):
        pack_match = re.search(r'(eval\(function\(p,a,c,k,e,(?:r|d)\).*?)</script>', html, re.DOTALL)
        if pack_match:
            html = _packer_unpack(pack_match.group(1))

    patterns = [
        r'MDCore\.wurl\s*=\s*"([^"]+)"',
        r'"wurl"\s*:\s*"([^"]+)"',
        r"wurl\s*=\s*'([^']+)'",
    ]
    for pattern in patterns:
        m = re.search(pattern, html, re.DOTALL)
        if m:
            url = m.group(1)
            if not url.startswith('http'):
                url = 'https:' + url
            log(f"[Resolver] Mixdrop => {url}")
            return url

    return None


def resolve_mp4upload(embed_url):
    """Resuelve URLs de mp4upload extrayendo la fuente del player."""
    log(f"[Resolver] Mp4upload: {embed_url}")
    html = get_html(embed_url, referer='https://www.mp4upload.com/')
    if not html:
        return None
    m = re.search(r'"file"\s*:\s*"([^"]+\.mp4[^"]*)"', html, re.IGNORECASE)
    if m:
        url = m.group(1)
        log(f"[Resolver] Mp4upload => {url}")
        return url
    return None


def resolve_okru(embed_url):
    """Resuelve URLs de OK.ru extrayendo la mejor calidad disponible."""
    log(f"[Resolver] OK.ru: {embed_url}")
    html = get_html(embed_url, referer=embed_url)
    if not html:
        return None

    # OK.ru guarda los datos en un atributo data-options JSON
    m = re.search(r'data-options="([^"]+)"', html)
    if m:
        try:
            data_str = m.group(1).replace('&quot;', '"')
            data = json.loads(data_str)
            # Navegar hasta flashvars.metadata.videos
            videos = data.get('flashvars', {}).get('metadata', {}).get('videos', [])
            if videos:
                # Obtener la máxima calidad disponible
                best = max(videos, key=lambda x: x.get('seekSchema', 0))
                url = best.get('url', '')
                if url:
                    log(f"[Resolver] OK.ru => {url}")
                    return url
        except Exception as e:
            log(f"[Resolver] OK.ru: Error procesando datos: {str(e)}", xbmc.LOGWARNING)

    return None


def resolve_netu(embed_url):
    """
    Resuelve URLs de Netu / waaw.to / hqq.tv
    Estos sitios requieren JS para reproducir, pero extraemos el token 'ws' del HTML
    y construimos la URL del video CDN directamente.
    URL patrón: https://waaw.to/e/VIDEO_ID o https://waaw.to/f/VIDEO_ID
    """
    log(f"[Resolver] Netu/waaw: {embed_url}")

    # Normalizar URL: /f/ -> /e/
    embed_url = re.sub(r'/f/([a-zA-Z0-9]+)', r'/e/\1', embed_url)

    parsed = urlparse(embed_url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    file_id = re.search(r'/e/([a-zA-Z0-9]+)', embed_url)
    if not file_id:
        log("[Resolver] Netu: No se encontró ID de archivo.", xbmc.LOGWARNING)
        return None
    file_id = file_id.group(1)

    h = HEADERS.copy()
    h['Referer'] = embed_url

    try:
        resp = requests.get(embed_url, headers=h, timeout=20)
        html = resp.text
    except Exception as e:
        log(f"[Resolver] Netu: Error HTTP: {str(e)}", xbmc.LOGWARNING)
        return None

    # Extraer el token 'ws' que contiene el md5 y timestamp
    ws_match = re.search(r"var ws\s*=\s*'([^']+)'", html)
    if not ws_match:
        log("[Resolver] Netu: No se encontró token ws.", xbmc.LOGWARNING)
        return None

    ws_token = ws_match.group(1)  # Ej: ?serv=1&md5=xxx&time=xxx&ip=xxx&userid=

    # Buscar el dominio CDN usado para el video
    # Netu sirve videos desde dominios cdn-s*.cfglobalcdn.com
    cdn_domain_match = re.search(r'cdn-s[\d]+\.cfglobalcdn\.com', html)

    # Intentar obtener la URL del video a través del endpoint del player
    player_url = f"{base}/player/index.php?v={file_id}"
    try:
        player_resp = requests.post(
            player_url,
            data={'r': '', 'd': parsed.netloc},
            headers={**h, 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=15
        )
        player_data = player_resp.text
        if player_data:
            # Buscar URLs de video en la respuesta
            video_urls = re.findall(r'(https?://[^\s"\',<>]+\.(?:m3u8|mp4)[^\s"\',<>]*)', player_data)
            if video_urls:
                url = video_urls[0] + ws_token
                log(f"[Resolver] Netu (player.php) => {url}")
                return url
    except Exception as e:
        log(f"[Resolver] Netu: Error player.php: {str(e)}", xbmc.LOGWARNING)

    log("[Resolver] Netu: No se pudo resolver (requiere JS). Intentar otro servidor.", xbmc.LOGWARNING)
    return None


def resolve_generic_iframe(embed_url):
    """
    Resolver genérico: busca fuentes de video directas (.m3u8, .mp4) en el HTML.
    Útil para sitios simples que no requieren descifrado.
    """
    log(f"[Resolver] Genérico: {embed_url}")
    html = get_html(embed_url, referer=embed_url)
    if not html:
        return None

    # Desempaquetar JS si es necesario
    if _packer_detect(html):
        pack_match = re.search(r'(eval\(function\(p,a,c,k,e,(?:r|d)\).*?)</script>', html, re.DOTALL)
        if pack_match:
            html = _packer_unpack(pack_match.group(1)) + html

    # Buscar URLs directas de video
    patterns = [
        r'"file"\s*:\s*"(https?://[^"]+\.(?:m3u8|mp4)[^"]*)"',
        r"'file'\s*:\s*'(https?://[^']+\.(?:m3u8|mp4)[^']*)'",
        r'src\s*[=:]\s*["\']?(https?://[^"\'>\s]+\.(?:m3u8|mp4)[^"\'>\s]*)',
        r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]*)?)',
    ]

    for pattern in patterns:
        m = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
        if m:
            url = m.group(1)
            log(f"[Resolver] Genérico => {url}")
            return url

    return None


def resolve_server(embed_url, server_name=''):
    """
    Enrutador principal de resolvers.
    Detecta el servidor por URL/nombre y llama al resolver apropiado.
    """
    if not embed_url:
        return None

    url_lower = embed_url.lower()
    server_lower = server_name.lower()

    log(f"[Resolver] Intentando resolver: {embed_url} (servidor={server_name})")

    # --- Streamwish y variantes ---
    streamwish_domains = [
        'streamwish', 'wishonly', 'jwplayerhls', 'embedwish', 'vidhidepro',
        'swdyu', 'filelions', 'playerwish', 'ajmidyad', 'tntsport',
        'wishfast', 'vidmovies', 'vidclouds', 'sfastwish', 'streamwish.to',
        'wishfast.top', 'streamwish.com'
    ]
    if any(d in url_lower or d in server_lower for d in streamwish_domains):
        result = resolve_streamwish(embed_url)
        if result:
            return result

    # --- Netu / waaw.to / hqq.tv ---
    netu_domains = ['waaw.to', 'netu.ac', 'netu.tv', 'hqq.tv', 'hqq.to', 'akpdm.top', 'netu']
    if any(d in url_lower or d in server_lower for d in netu_domains):
        result = resolve_netu(embed_url)
        if result:
            return result
        # Si no se pudo resolver Netu, informar al usuario claramente
        log(f"[Resolver] Netu/waaw requiere JS — no se puede resolver sin navegador.", xbmc.LOGWARNING)
        return None

    # --- Filemoon y variantes ---
    filemoon_domains = ['filemoon', 'filemooon', 'moonplayer', 'kerapoxy']
    if any(d in url_lower or d in server_lower for d in filemoon_domains):
        result = resolve_filemoon(embed_url)
        if result:
            return result

    # --- Streamtape ---
    if 'streamtape' in url_lower or 'streamtape' in server_lower:
        result = resolve_streamtape(embed_url)
        if result:
            return result

    # --- Doodstream y variantes ---
    dood_domains = ['doodstream', 'dood.', 'ds2play', 'doods.', 'dooood']
    if any(d in url_lower or d in server_lower for d in dood_domains):
        result = resolve_doodstream(embed_url)
        if result:
            return result

    # --- VOE ---
    if 'voe.sx' in url_lower or 'voe' in server_lower:
        result = resolve_voe(embed_url)
        if result:
            return result

    # --- Mixdrop ---
    if 'mixdrop' in url_lower or 'mixdrop' in server_lower:
        result = resolve_mixdrop(embed_url)
        if result:
            return result

    # --- Mp4upload ---
    if 'mp4upload' in url_lower or 'mp4upload' in server_lower:
        result = resolve_mp4upload(embed_url)
        if result:
            return result

    # --- OK.ru ---
    if 'ok.ru' in url_lower or 'okru' in server_lower:
        result = resolve_okru(embed_url)
        if result:
            return result

    # --- Si la URL ya es directa (.m3u8, .mp4) ---
    if any(ext in url_lower for ext in ['.m3u8', '.mp4', '.mkv', '.avi']):
        log(f"[Resolver] URL ya es directa: {embed_url}")
        return embed_url

    # --- Intentar resolver con resolveurl si está disponible ---
    if RESOLVEURL_AVAILABLE:
        try:
            log("[Resolver] Intentando con resolveurl...")
            result = resolveurl.resolve(embed_url)
            if result:
                log(f"[Resolver] resolveurl => {result}")
                return result
        except Exception as e:
            log(f"[Resolver] resolveurl falló: {str(e)}", xbmc.LOGWARNING)

    # --- Último recurso: resolver genérico ---
    result = resolve_generic_iframe(embed_url)
    if result:
        return result

    log(f"[Resolver] No se pudo resolver la URL: {embed_url}", xbmc.LOGWARNING)
    return None


# ===========================================================================
# LÓGICA DEL ADDON (BÚSQUEDA, SERIES, EPISODIOS, REPRODUCCIÓN)
# ===========================================================================

def search(query):
    """Realiza la búsqueda en el sitio y muestra los resultados en Kodi."""
    search_url = f"{BASE_URL}/search?q={quote_plus(query)}"
    log(f"Iniciando búsqueda para: {query}")

    html = get_html(search_url)
    if not html:
        return

    soup = BeautifulSoup(html, 'html.parser')
    # Buscar tarjetas de resultados en el HTML de la web
    cards = soup.find_all('div', class_='TPost') or soup.find_all('li', class_='TPostMv')

    results = []
    for card in cards:
        try:
            a_tag = card.find('a', href=True)
            if not a_tag:
                continue

            href = a_tag['href']
            # Solo películas y series
            if '/pelicula/' not in href and '/serie/' not in href:
                continue

            url = href if href.startswith('http') else BASE_URL + href

            # Título desde alt de imagen o headings
            img_tag = card.find('img')
            title = ""
            if img_tag and img_tag.get('alt'):
                title = img_tag['alt'].strip()

            if not title:
                h2_tag = card.find(['h2', 'h3'])
                title = h2_tag.get_text(strip=True) if h2_tag else a_tag.get_text(strip=True)

            title = re.sub(r'^(Pelicula|Serie)\s*', '', title, flags=re.IGNORECASE)

            # Miniatura
            thumbnail = ""
            if img_tag:
                img_src = img_tag.get('src') or img_tag.get('data-src') or ""
                if 'url=' in img_src:
                    try:
                        parsed = urlparse(img_src)
                        qs = parse_qs(parsed.query)
                        if 'url' in qs:
                            thumbnail = qs['url'][0]
                    except Exception:
                        pass
                if not thumbnail and img_src:
                    if img_src.startswith('//'):
                        thumbnail = 'https:' + img_src
                    elif img_src.startswith('/'):
                        thumbnail = BASE_URL + img_src
                    else:
                        thumbnail = img_src

            results.append({
                'title': title,
                'url': url,
                'thumbnail': thumbnail,
                'is_series': '/serie/' in href
            })
        except Exception as e:
            log(f"Error procesando tarjeta de resultado: {str(e)}", xbmc.LOGWARNING)
            continue

    if not results:
        dialog = xbmcgui.Dialog()
        dialog.ok("Sin Resultados", f"No se encontraron películas o series para: '{query}'")
        return

    handle = int(sys.argv[1])
    for item in results:
        list_item = xbmcgui.ListItem(label=item['title'])
        list_item.setArt({'thumb': item['thumbnail'], 'poster': item['thumbnail']})

        if item['is_series']:
            callback_url = f"{sys.argv[0]}?action=seasons&url={quote_plus(item['url'])}"
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            callback_url = f"{sys.argv[0]}?action=play&url={quote_plus(item['url'])}"
            is_folder = False

        xbmcplugin.addDirectoryItem(handle, callback_url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(handle)


def list_seasons(series_url):
    """Muestra el listado de temporadas de una serie."""
    log(f"Listando temporadas para: {series_url}")
    html = get_html(series_url)
    next_data = extract_next_data(html)

    if not next_data:
        show_notification("Error", "No se pudieron obtener las temporadas.")
        return

    try:
        page_props = next_data.get('props', {}).get('pageProps', {})
        this_serie = page_props.get('thisSerie', {})
        seasons = this_serie.get('seasons', [])

        if not seasons:
            show_notification("Aviso", "Esta serie no contiene temporadas disponibles.")
            return

        handle = int(sys.argv[1])
        for season in seasons:
            season_num = season.get('number')
            if season_num is None or not season.get('episodes'):
                continue

            label = f"Temporada {season_num}" if season_num != 0 else "Especiales / Temporada 0"

            list_item = xbmcgui.ListItem(label=label)
            poster = this_serie.get('images', {}).get('poster', '')
            if poster:
                list_item.setArt({'thumb': poster, 'poster': poster})

            callback_url = f"{sys.argv[0]}?action=episodes&url={quote_plus(series_url)}&season={season_num}"
            xbmcplugin.addDirectoryItem(handle, callback_url, list_item, isFolder=True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        log(f"Error procesando temporadas: {str(e)}", xbmc.LOGERROR)
        show_notification("Error", "Fallo al procesar listado de temporadas.")


def list_episodes(series_url, season_num):
    """Muestra los episodios de una temporada específica."""
    log(f"Listando episodios para la temporada {season_num} de: {series_url}")
    html = get_html(series_url)
    next_data = extract_next_data(html)

    if not next_data:
        show_notification("Error", "No se pudieron obtener los episodios.")
        return

    try:
        page_props = next_data.get('props', {}).get('pageProps', {})
        this_serie = page_props.get('thisSerie', {})
        seasons = this_serie.get('seasons', [])

        target_season = None
        for s in seasons:
            if str(s.get('number')) == str(season_num):
                target_season = s
                break

        if not target_season or not target_season.get('episodes'):
            show_notification("Aviso", "No se encontraron episodios en esta temporada.")
            return

        handle = int(sys.argv[1])
        for ep in target_season.get('episodes', []):
            ep_num = ep.get('number', 1)
            title = ep.get('title') or f"Episodio {ep_num}"

            slug = ep.get('url', {}).get('slug', '')
            if not slug:
                continue

            # Convertir slug de API a URL de la web
            slug = slug.replace('seasons', 'temporada').replace('episodes', 'episodio').replace('series/', 'serie/')
            ep_url = f"{BASE_URL}/{slug}" if not slug.startswith('http') else slug

            ep_label = f"{season_num}x{ep_num:02d} - {title}"
            list_item = xbmcgui.ListItem(label=ep_label)

            thumb = ep.get('image') or this_serie.get('images', {}).get('poster', '')
            list_item.setArt({'thumb': thumb, 'poster': thumb})
            list_item.setProperty('IsPlayable', 'true')

            callback_url = f"{sys.argv[0]}?action=play&url={quote_plus(ep_url)}"
            xbmcplugin.addDirectoryItem(handle, callback_url, list_item, isFolder=False)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        log(f"Error al listar episodios: {str(e)}", xbmc.LOGERROR)
        show_notification("Error", "Fallo al procesar listado de episodios.")


def _get_player_embed_url(player_page_url, content_url):
    """
    Obtiene la URL del embed del reproductor desde una URL de player.php.
    Soporta múltiples patrones de extracción.
    """
    player_html = get_html(player_page_url, referer=content_url)
    if not player_html:
        return None, None

    # Patrón 1: var url = 'https://streamwish.to/e/...'
    m = re.search(r"var\s+url\s*=\s*['\"]([^'\"]+)['\"]", player_html)
    if m:
        return m.group(1), player_html

    # Patrón 2: iframe con src
    m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', player_html, re.IGNORECASE)
    if m:
        return m.group(1), player_html

    # Patrón 3: buscar cualquier enlace https en el JS
    m = re.search(r'["\']((https?://(?:streamwish|filemoon|filemooon|doodstream|streamtape|voe|mixdrop)[^"\']+))["\']',
                  player_html, re.IGNORECASE)
    if m:
        return m.group(1), player_html

    # Patrón 4: buscar enlace en data o script tags
    soup = BeautifulSoup(player_html, 'html.parser')
    for script in soup.find_all('script'):
        script_text = script.string or ''
        m = re.search(r"(?:url|src|source|embed)\s*[=:]\s*['\"]?(https?://[^'\">\s]+)['\"]?",
                      script_text, re.IGNORECASE)
        if m:
            url = m.group(1)
            if any(d in url.lower() for d in ['streamwish', 'filemoon', 'dood', 'streamtape', 'voe', 'mixdrop', 'jwplayer', 'wishonly']):
                return url, player_html

    return None, player_html


def play(content_url):
    """Visita la URL del contenido, resuelve el reproductor y lo reproduce en Kodi."""
    log(f"Preparando reproducción de contenido desde: {content_url}")

    html = get_html(content_url)
    next_data = extract_next_data(html)

    if not next_data:
        show_notification("Error de Datos", "No se pudo leer la información de los videos.")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return

    try:
        page_props = next_data.get('props', {}).get('pageProps', {})

        # Buscar la sección de videos
        videos_data = None
        for key in ['thisMovie', 'episode', 'thisSerie', 'thisEpisode']:
            if key in page_props and 'videos' in page_props[key]:
                videos_data = page_props[key]['videos']
                break

        if not videos_data:
            for k, v in page_props.items():
                if isinstance(v, dict) and 'videos' in v:
                    videos_data = v['videos']
                    break

        if not videos_data or not isinstance(videos_data, dict):
            show_notification("Sin Enlaces", "No se encontraron enlaces de video disponibles.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        # Construir la lista de opciones de reproducción
        options = []
        for lang, list_vids in videos_data.items():
            if not list_vids or not isinstance(list_vids, list):
                continue
            for vid in list_vids:
                cyberlocker = vid.get('cyberlocker', 'Desconocido')
                quality = vid.get('quality', 'HD')
                player_url = vid.get('result', '')

                if player_url:
                    lang_display = {
                        'latino': 'Latino',
                        'spanish': 'Español',
                        'english': 'Inglés',
                        'subtitulado': 'Subtitulado'
                    }.get(lang.lower(), lang.upper())

                    options.append({
                        'label': f"[{lang_display}] {cyberlocker.capitalize()} ({quality})",
                        'player_url': player_url,
                        'server': cyberlocker.lower(),
                        'lang': lang_display,
                        'quality': quality
                    })

        if not options:
            show_notification("Sin Servidores", "No hay servidores de reproducción disponibles.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        # Mostrar diálogo de selección al usuario
        dialog = xbmcgui.Dialog()
        labels = [opt['label'] for opt in options]
        selected_index = dialog.select("Selecciona idioma y servidor", labels)

        if selected_index == -1:
            log("Reproducción cancelada por el usuario.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        selected = options[selected_index]
        player_page_url = selected['player_url']
        server_name = selected['server']
        log(f"Opción seleccionada: {selected['label']} => {player_page_url}")

        # PASO 1: Ir a player.php para obtener la URL del embed externo
        embed_url, _ = _get_player_embed_url(player_page_url, content_url)

        if not embed_url:
            # Si no se encontró embed, tal vez player_url sea directamente el embed
            embed_url = player_page_url

        log(f"URL del embed obtenida: {embed_url}")

        # PASO 2: Resolver la URL del embed al stream final
        show_notification(ADDON_NAME, f"Resolviendo {server_name}...", time_ms=3000)
        final_url = resolve_server(embed_url, server_name)

        if not final_url:
            show_notification(
                "Error de Servidor",
                f"No se pudo obtener el stream de '{server_name.capitalize()}'. "
                "Prueba con otro servidor.",
                time_ms=6000
            )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        log(f"Reproduciendo URL final: {final_url}")
        play_item = xbmcgui.ListItem(path=final_url)
        # Configurar headers si la URL los incluye con pipe
        if '|' in final_url:
            url_part, headers_part = final_url.split('|', 1)
            play_item = xbmcgui.ListItem(path=url_part)
            play_item.setProperty('inputstream.adaptive.stream_headers', headers_part)
            play_item.setProperty('inputstream.adaptive.manifest_headers', headers_part)

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
        show_notification(ADDON_NAME, f"Reproduciendo en {server_name}...", time_ms=3000)

    except Exception as e:
        log(f"Error general en play(): {str(e)}", xbmc.LOGERROR)
        show_notification("Error Inesperado", f"Error: {str(e)}")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())


# ===========================================================================
# PUNTO DE ENTRADA
# ===========================================================================

def main():
    """Punto de entrada principal del addon."""
    paramstring = sys.argv[2] if len(sys.argv) > 2 else ''
    params = dict(parse_qsl(paramstring.lstrip('?')))

    action = params.get('action')

    if not action:
        # Lanzar teclado nativo de Kodi automáticamente
        keyboard = xbmc.Keyboard('', f"{ADDON_NAME} - ¿Qué deseas buscar?")
        keyboard.doModal()

        if keyboard.isConfirmed():
            query = keyboard.getText().strip()
            if query:
                search(query)
            else:
                xbmcgui.Dialog().ok(ADDON_NAME, "No ingresaste ningún texto de búsqueda.")
                xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)

    elif action == 'seasons':
        series_url = params.get('url')
        if series_url:
            list_seasons(series_url)

    elif action == 'episodes':
        series_url = params.get('url')
        season_num = params.get('season')
        if series_url and season_num is not None:
            list_episodes(series_url, season_num)

    elif action == 'play':
        content_url = params.get('url')
        if content_url:
            play(content_url)


if __name__ == '__main__':
    main()